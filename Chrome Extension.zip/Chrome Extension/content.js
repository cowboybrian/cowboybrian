alert("Hello From A Coder")
alert("Come Visit Las Vegas")
alert("Here's Another Pop up")
alert("OMG!! Here's Another One")
alert("WHEN WILL THE MADNESS END?!")
alert("After The Pop Ups, Click Around The Webpage")
alert("Okay, Serisously This Is The Last One... Hope You Liked My Extension")

document.addEventListener('click', () => {
	let url = chrome.runtime.getURL('fart2.wav')
	console.log(url)

	let a = new Audio(url)
	a.play()
})